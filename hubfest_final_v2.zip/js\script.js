/**
 * HubFest - Script Principal
 */

document.addEventListener('DOMContentLoaded', () => {
    feather.replace();
    setupNavigation();
    renderData();
    setupFilters();
    initCalendar(); // New init

    document.addEventListener('festasUpdated', () => {
        renderFestas();
        renderCalendar(); // Re-render to show new event dots
        updateDashboardCounts();
    });
    document.addEventListener('tarefasUpdated', () => {
        renderTarefas();
        updateDashboardCounts();
    });
});

window.navTo = function (targetId) {
    showSection(targetId);
}

// --- MODAL & CRUD LOGIC ---

// --- FESTAS ---
window.openPartyModal = function (id = null) {
    const modal = document.getElementById('modal-overlay');
    const modalContent = document.getElementById('modal-festa');
    const title = document.getElementById('modal-festa-title');
    const form = document.getElementById('form-festa');

    form.reset(); // Clear previous data

    if (id) {
        // Edit Mode
        const festa = Store.getFestas().find(f => f.id === id);
        if (!festa) return;

        title.innerText = 'Editar Festa';
        document.getElementById('festa-id').value = festa.id;
        document.getElementById('festa-nome').value = festa.nome;
        document.getElementById('festa-responsavel').value = festa.responsavel || '';
        document.getElementById('festa-data').value = festa.data || '';
        document.getElementById('festa-hora').value = festa.hora || '';
        document.getElementById('festa-telefone').value = festa.telefone || '';
        document.getElementById('festa-status').value = festa.status || 'neutral';
        document.getElementById('festa-idade').value = festa.idade ? festa.idade.replace(' anos', '') : '';
        document.getElementById('festa-criancas').value = festa.criancas || '';
        document.getElementById('festa-obs').value = festa.obs || '';
    } else {
        // Create Mode
        title.innerText = 'Nova Festa';
        document.getElementById('festa-id').value = '';
    }

    // Toggle Visibility
    modal.classList.add('active');
    document.getElementById('modal-tarefa').style.display = 'none';
    modalContent.style.display = 'flex';
}

window.editarFesta = function (id) {
    openPartyModal(id);
}

window.excluirFesta = function (id) {
    if (confirm('Tem certeza que deseja excluir esta festa?')) {
        Store.deleteFesta(id);
    }
}

document.getElementById('form-festa').addEventListener('submit', (e) => {
    e.preventDefault();
    const id = document.getElementById('festa-id').value;

    // Status Logic for Label
    const statusVal = document.getElementById('festa-status').value;
    let statusLabel = 'Pendente';
    if (statusVal === 'warning') statusLabel = 'Planejamento';
    if (statusVal === 'success') statusLabel = 'Confirmada';

    const festaData = {
        id: id || undefined, // undefined lets Store generate ID
        nome: document.getElementById('festa-nome').value,
        responsavel: document.getElementById('festa-responsavel').value,
        data: document.getElementById('festa-data').value,
        hora: document.getElementById('festa-hora').value,
        telefone: document.getElementById('festa-telefone').value,
        status: statusVal,
        statusLabel: statusLabel,
        idade: document.getElementById('festa-idade').value + ' anos',
        criancas: document.getElementById('festa-criancas').value,
        obs: document.getElementById('festa-obs').value
    };

    if (id) {
        Store.updateFesta(festaData);
    } else {
        Store.addFesta(festaData);
    }

    closeModals();
});


// --- TAREFAS ---
window.openTaskModal = function (id = null) {
    const modal = document.getElementById('modal-overlay');
    const modalContent = document.getElementById('modal-tarefa');
    const title = document.getElementById('modal-tarefa-title');
    const form = document.getElementById('form-tarefa');

    form.reset();

    if (id) {
        const tarefa = Store.getTarefas().find(t => t.id === id);
        if (!tarefa) return;
        title.innerText = 'Editar Tarefa';
        document.getElementById('tarefa-id').value = tarefa.id;
        document.getElementById('tarefa-titulo').value = tarefa.titulo;
    } else {
        title.innerText = 'Nova Tarefa';
        document.getElementById('tarefa-id').value = '';
    }

    modal.classList.add('active');
    document.getElementById('modal-festa').style.display = 'none';
    modalContent.style.display = 'flex';
}

window.editarTarefa = function (id) {
    openTaskModal(id);
}

window.excluirTarefa = function (id) {
    if (confirm('Excluir esta tarefa?')) {
        Store.deleteTarefa(id);
    }
}

document.getElementById('form-tarefa').addEventListener('submit', (e) => {
    e.preventDefault();
    const id = document.getElementById('tarefa-id').value;
    const tarefaData = {
        id: id || undefined,
        titulo: document.getElementById('tarefa-titulo').value,
        // Preserves 'feita' status if updating, or defaults to false in Store if new
    };

    if (id) {
        const existing = Store.getTarefas().find(t => t.id === id);
        if (existing) tarefaData.feita = existing.feita; // Keep checked status
        Store.updateTarefa(tarefaData);
    } else {
        Store.addTarefa(tarefaData);
    }
    closeModals();
});


window.closeModals = function () {
    const modal = document.getElementById('modal-overlay');
    modal.classList.remove('active');
    // slight delay to clear content display for animation reset
    setTimeout(() => {
        document.getElementById('modal-festa').style.display = 'none';
        document.getElementById('modal-tarefa').style.display = 'none';
    }, 200);
}


// --- DOM HELPERS ---

const menuItems = document.querySelectorAll('.menu-item');
const contentSections = document.querySelectorAll('.content-section');

function setupNavigation() {
    menuItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = item.getAttribute('data-target');
            if (targetId) showSection(targetId);
        });
    });
}

function showSection(targetId) {
    contentSections.forEach(sec => sec.classList.remove('active'));
    menuItems.forEach(item => item.classList.remove('active'));

    const targetSection = document.getElementById(targetId);
    if (targetSection) targetSection.classList.add('active');

    const activeBtn = document.querySelector(`.menu-item[data-target="${targetId}"]`);
    if (activeBtn) activeBtn.classList.add('active');
}

function renderData() {
    renderFestas();
    renderTarefas();
    updateDashboardCounts();
}

/**
 * --- CALENDAR LOGIC ---
 */
let currentCalDate = new Date(2026, 0, 19); // Start at Jan 2026 as per prompt, or use new Date()
let selectedDate = new Date(2026, 0, 19);

function initCalendar() {
    document.getElementById('prev-month').addEventListener('click', () => {
        currentCalDate.setMonth(currentCalDate.getMonth() - 1);
        renderCalendar();
    });
    document.getElementById('next-month').addEventListener('click', () => {
        currentCalDate.setMonth(currentCalDate.getMonth() + 1);
        renderCalendar();
    });

    renderCalendar();
    renderDayDetails(selectedDate);
}

function renderCalendar() {
    const grid = document.getElementById('calendar-grid');
    const title = document.getElementById('calendar-title');
    const festas = Store.getFestas();

    // Set Title (Ex: Janeiro 2026)
    const monthNames = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
    title.innerText = `${monthNames[currentCalDate.getMonth()]} ${currentCalDate.getFullYear()}`;

    grid.innerHTML = '';

    // Logic for days
    const firstDayOfMonth = new Date(currentCalDate.getFullYear(), currentCalDate.getMonth(), 1);
    const lastDayOfMonth = new Date(currentCalDate.getFullYear(), currentCalDate.getMonth() + 1, 0);
    const daysInMonth = lastDayOfMonth.getDate();

    // Padding days (previous month)
    const startingDayOfWeek = firstDayOfMonth.getDay(); // 0 (Sun) to 6 (Sat)

    for (let i = 0; i < startingDayOfWeek; i++) {
        const day = document.createElement('div');
        day.classList.add('calendar-day', 'prev-month');
        // Optional: show number of prev month day? Keeping empty for simplicity or calculate needed.
        grid.appendChild(day);
    }

    // Days of current month
    for (let i = 1; i <= daysInMonth; i++) {
        const day = document.createElement('div');
        day.classList.add('calendar-day');
        day.innerText = i;

        // Construct date string YYYY-MM-DD for comparison
        const monthStr = (currentCalDate.getMonth() + 1).toString().padStart(2, '0');
        const dayStr = i.toString().padStart(2, '0');
        const dateString = `${currentCalDate.getFullYear()}-${monthStr}-${dayStr}`;

        // Check for events
        const hasEvent = festas.some(f => f.data === dateString);
        if (hasEvent) day.classList.add('has-event');

        // Check selected
        if (selectedDate &&
            selectedDate.getDate() === i &&
            selectedDate.getMonth() === currentCalDate.getMonth() &&
            selectedDate.getFullYear() === currentCalDate.getFullYear()) {
            day.classList.add('selected');
        }

        // Click Handler
        day.addEventListener('click', () => {
            selectedDate = new Date(currentCalDate.getFullYear(), currentCalDate.getMonth(), i);
            renderCalendar(); // Re-render to update selected class
            renderDayDetails(selectedDate);
        });

        grid.appendChild(day);
    }
}

function renderDayDetails(date) {
    const content = document.getElementById('day-details-content');
    const monthNames = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"];

    // Format Date Title
    const headerHtml = `
        <h2 id="selected-date-title">${date.getDate()} de ${monthNames[date.getMonth()]} de ${date.getFullYear()}</h2>
    `;

    // Get Events
    const monthStr = (date.getMonth() + 1).toString().padStart(2, '0');
    const dayStr = date.getDate().toString().padStart(2, '0');
    const dateString = `${date.getFullYear()}-${monthStr}-${dayStr}`;

    const events = Store.getFestas().filter(f => f.data === dateString);

    if (events.length === 0) {
        content.innerHTML = `
            <div class="empty-day-state">
                ${headerHtml}
                <p>Nenhuma festa agendada para esta data.</p>
            </div>
        `;
    } else {
        const eventsHtml = events.map(f => `
            <div class="cal-event-card">
                <h4>${f.nome}</h4>
                <p>${f.hora} • ${f.local || 'Local não definido'}</p>
                <span class="cal-event-status">${f.statusLabel || 'Confirmado'}</span>
            </div>
        `).join('');

        content.innerHTML = `
            <div style="text-align: center;">${headerHtml}</div>
            <div style="margin-top: 2rem;">
                ${eventsHtml}
            </div>
        `;
    }
}

/**
 * --- EXISTING FUNCTIONS ---
 */

// --- FILTERS & SEARCH STATE ---
let currentSearch = '';
let currentFilter = 'all';

function setupFilters() {
    const searchInput = document.getElementById('party-search');
    const filterBtns = document.querySelectorAll('.filter-chip');

    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            currentSearch = e.target.value.toLowerCase();
            renderFestas();
        });
    }

    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            // Remove active from all
            filterBtns.forEach(b => b.classList.remove('active'));
            // Add active to clicked
            btn.classList.add('active');

            currentFilter = btn.getAttribute('data-filter');
            renderFestas();
        });
    });
}

function renderFestas() {
    let festas = Store.getFestas();
    const container = document.getElementById('lista-festas');
    if (!container) return;

    // --- FILTER & SEARCH LOGIC ---
    // 1. Filter by Status
    if (currentFilter !== 'all') {
        if (currentFilter === 'confirmada') {
            festas = festas.filter(f => f.status === 'success');
        } else if (currentFilter === 'pendente') {
            festas = festas.filter(f => f.status === 'neutral' || f.status === 'warning');
        }
    }

    // 2. Filter by Search (Name or Responsible)
    if (currentSearch) {
        festas = festas.filter(f =>
            f.nome.toLowerCase().includes(currentSearch) ||
            (f.responsavel && f.responsavel.toLowerCase().includes(currentSearch))
        );
    }
    // ----------------------------

    container.style.display = 'grid';
    container.style.gridTemplateColumns = 'repeat(auto-fill, minmax(320px, 1fr))';
    container.style.gap = '1.5rem';

    if (festas.length === 0) {
        // Different empty state if searching vs just empty
        const msg = (currentSearch || currentFilter !== 'all')
            ? 'Nenhuma festa encontrada para sua busca.'
            : 'Nenhuma festa cadastrada.';
        container.innerHTML = `<div class="card empty-state-card"><p>${msg}</p></div>`;
        return;
    }

    container.innerHTML = festas.map(f => `
        <div class="card party-card-rect">
            <div class="card-header-row">
                <h3 class="party-title">${f.nome}</h3>
                <span class="badge ${f.status || 'neutral'}">${f.statusLabel || 'Geral'}</span>
            </div>
            <p class="party-subtitle">${f.responsavel || 'Sem responsável'}</p>
            <div class="party-info-row">
                <div class="info-item">
                    <i data-feather="calendar"></i>
                    <span>${formatDate(f.data)}</span>
                </div>
                <div class="info-item">
                    <i data-feather="phone"></i>
                    <span>${f.telefone || 'Sem telefone'}</span>
                </div>
            </div>
            <div class="party-details-row">
                <div class="detail-box">
                    <span class="detail-key">Idade:</span>
                    <span class="detail-val">${f.idade || '-'}</span>
                </div>
                <div class="detail-box">
                    <span class="detail-key">Crianças:</span>
                    <span class="detail-val">${f.criancas || '-'}</span>
                </div>
            </div>
            <div class="card-actions-footer">
                <button class="btn-action primary" onclick="editarFesta('${f.id}')">
                    <i data-feather="edit-2"></i>
                    Editar
                </button>
                <button class="btn-action icon-only delete" onclick="excluirFesta('${f.id}')">
                    <i data-feather="trash-2"></i>
                </button>
            </div>
        </div>
    `).join('');
    feather.replace();
}

function renderTarefas() {
    const tarefas = Store.getTarefas();
    const container = document.getElementById('lista-tarefas');
    if (!container) return;
    if (tarefas.length === 0) {
        container.innerHTML = '<div class="card empty-state-card"><p>Nenhuma tarefa pendente.</p></div>';
        return;
    }
    container.innerHTML = tarefas.map(t => `
        <div class="card list-item">
            <div style="display:flex; align-items:center; gap:1rem; flex:1;">
                <input type="checkbox" ${t.feita ? 'checked' : ''} onchange="toggleTask('${t.id}')">
                <div class="item-info" style="flex:1;">
                    <h3 style="${t.feita ? 'text-decoration: line-through; opacity: 0.7' : ''}; font-size:1rem; margin:0;">${t.titulo}</h3>
                </div>
            </div>
            <div class="item-actions">
                <button onclick="editarTarefa('${t.id}')" title="Editar"><i data-feather="edit-2" style="width:16px"></i></button>
                <button class="delete" onclick="excluirTarefa('${t.id}')" title="Excluir"><i data-feather="trash-2" style="width:16px"></i></button>
            </div>
        </div>
    `).join('');
    feather.replace();
}

window.toggleTask = function (id) {
    Store.toggleTarefa(id);
}

// --- SETTINGS LOGIC ---

window.resetAppData = function () {
    if (confirm('Tem certeza? Isso apagará TODAS as festas e tarefas.\nEsta ação não pode ser desfeita.')) {
        Store.clearAll();
        alert('Dados limpos com sucesso!');
        location.reload();
    }
}

window.reloadDemoData = function () {
    if (confirm('Isso apagará os dados atuais e recarregará os exemplos (Julia e Miguel).\nContinuar?')) {
        Store.clearAll();
        // data.js init runs on load if empty, so reload triggers it
        location.reload();
    }
}

function updateDashboardCounts() {
    const festas = Store.getFestas();
    const tarefas = Store.getTarefas();
    const pendentes = festas.filter(f => f.status === 'warning' || f.status === 'neutral').length;
    const confirmadas = festas.filter(f => f.status === 'success').length;
    const tarefasAtivas = tarefas.filter(t => !t.feita).length;

    if (document.getElementById('dash-pendentes')) document.getElementById('dash-pendentes').innerText = pendentes;
    if (document.getElementById('dash-ativas')) document.getElementById('dash-ativas').innerText = tarefasAtivas;
    if (document.getElementById('dash-confirmadas')) document.getElementById('dash-confirmadas').innerText = confirmadas;
}

function formatDate(dateStr) {
    if (!dateStr) return '';
    const parts = dateStr.split('-');
    if (parts.length === 3) return `${parts[2]}/${parts[1]}/${parts[0]}`;
    return dateStr;
}
